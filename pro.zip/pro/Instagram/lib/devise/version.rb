# frozen_string_literal: true

module Devise
  VERSION = "5.0.0.beta".freeze
end
