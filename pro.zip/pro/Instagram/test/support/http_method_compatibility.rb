# frozen_string_literal: true

module Devise
  class IntegrationTest < ActionDispatch::IntegrationTest
  end

  class ControllerTestCase < ActionController::TestCase
  end
end
