# frozen_string_literal: true

class Users::Mailer < Devise::Mailer
  default from: 'custom@example.com'
end
